from knn import KNNClassifier, BatchedKNNClassifier
import random


def n_random(n, a, b):
    return [random.randint(a, b) for i in range(n)]


def n_random_features(n, X_train, Y_train, X_test, Y_test):
    randomized_indexes = n_random(n, 0, 784-1)
    x_train = X_train.iloc[randomized_indexes].to_numpy().astype(int)
    x_test = X_test.iloc[randomized_indexes].to_numpy().astype(int)
    y_train = Y_train.iloc[randomized_indexes].to_numpy().astype(int)
    y_test = Y_test.iloc[randomized_indexes].to_numpy().astype(int)
    return x_train, x_test, y_train, y_test
    

def create_classifier(algorithm, x_train, y_train):
    classifier = BatchedKNNClassifier(5, algorithm)
    classifier.fit(x_train, y_train)
    return classifier
