from matplotlib import pyplot as plt


def graph(matrix):
    plt.plot((matrix[0]),(matrix[1]))
    plt.show()
